% This code is for performing the continuum removal using NMF

% Bardia YOUSEFI 12.Oct 2017 (bardia.yousefi@ieee.org)
clear; clc; close all, warning off

cd('\\gel.ulaval.ca\Vision\Usagers\bayou2\MATLAB\Col-GEO\Continuum removal codes_J0'), CF0 = pwd;
cd('\\gel.ulaval.ca\Vision\Usagers\bayou2\MATLAB\Col-GEO\GT-team\Data\New Data.sc\'), CFs = pwd;
 Mineral = 'Biotite'; % Biotite Diopside Epidote Geothite Kyanite Scheelite Smithsonite Tourmaline Pyrope Olivine Quartz
L_ON = ['20151208_154909332_Biotite_G_ON.radiance.sc'];
L_OFF = ['20151208_155132908_Biotite_G_OFF.radiance.sc'];
%  snr = 0.1;
 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cd '\\gel.ulaval.ca\Vision\Usagers\bayou2\MATLAB\Col-GEO\Continuum removal codes_J0\Telops'
CFt = cd(pwd);
  addpath(CFt);
    % codes path
  CF1 = [ CFt, '\Matlab_customer\p_files'];
  addpath(CF1);
  cd(CF1);
  pathaddress = [CF1,'\Subfunctions'];
  addpath(pathaddress);
  cd(CFt)
% ---------------------------------------------------------------------  
% %  FilePath = [CFs];
% % %  FileName = '20150402_214243384_PYR-QTZ-FELD_ON.radiance.sc';
 filename = [CFs,'\',L_ON];
 [Data_ON,DerivedFromHeader_ON,Header_ON] = readHyperCam(filename);
    %Grid generation
   sigma = buildSigmaGrid(DerivedFromHeader_ON); 
   %Plot broad band image
   kk = (sigma>850 & sigma<1250);
   IRimage = formImage(Header_ON,mean(real(Data_ON(kk,:))));
   Clims1 = imageScalingLimits(IRimage(:));
   figure;imshow(IRimage,Clims1)
% ---------------------------------------------------------------------

%  Necessary files pixels points for pure and mixed mineral grains in the
%  hyper image are loading here.
J = imadjust(IRimage,Clims1);
BW = roipoly(J);
[row,col] = find(BW == 1);
infraGold = [row,col];
SZ = size(J);

% will give "TR" whic
% FilePath = [CF0,'\mesures_2avril2015\'];
%  FileName = '20150402_214509062_PYR-QTZ-FELD_OFF.radiance.sc';
%  filename = [FilePath,FileName];
 filename = [CFs,'\',L_OFF];
 [Data_OFF,DerivedFromHeader_OFF,Header_OFF] = readHyperCam(filename);
    %Grid generation
% %    sigma = buildSigmaGrid(DerivedFromHeader); 
%    %Plot broad band image
%    kk = (sigma>850 & sigma<1250);
%    IRimage = formImage(Header,mean(real(Data(kk,:))));
%    Clims1 = imageScalingLimits(IRimage(:));
%    figure;imshow(IRimage,Clims1)
% [Li_ON] = readHypData(filename,egc(1,2),egc(1,1));
% for i = 1 : size(infraGold,1)
    pixels = getAoiIndices(Header_ON, buildAoi(1, 1, infraGold(:,2)-1, infraGold(:,1)-1)); 
    
%  ================================================================   
    % Showing the reflectance point
figure; imshow(imadjust(IRimage,Clims1));
[x, y] = getpts

pixels1 = getAoiIndices(Header_ON, buildAoi(1, 1, x, y)); 
    

%%  
 snr = 0.0;
% ==================================================================
    Data_ONc = Data_ON;
    Data_ON = Data_ON + snr*rand([size(Data_OFF,1), size(Data_OFF,2)]);%awgn(Data_ON,snr);
    
    Data_OFFc = Data_OFF;
    Data_OFF = Data_OFF + snr*rand([size(Data_OFF,1), size(Data_OFF,2)]);%awgn(Data_OFF,snr);    
% ==================================================================    
  tic  
    Li_ON = mean(Data_ON(:,pixels),2);
    
       Li_OFF = mean(Data_OFF(:,pixels),2);

for i = 1 : size(Data_ON,2)       
       Reflectance(:,i) = (Data_ONc(:,i) - Data_OFFc(:,i)) ./ (Li_ON - Li_OFF);
end
time_Avg = toc
%SNMF: The standard NMF optimized by gradient-descent-based multiplicative rules. ==========================================================

addpath([CF0,'\sparse-nmfv1_4'])
cd([CF0,'\sparse-nmfv1_4'])
% ON
tic
[A_ON_NMFGD,Y,numIter,tElapsed,finalResidual] = nmfrule(Data_ON(:,pixels),3);
% toc
% OFF
% tic
[A_OFF_NMFGD,Y,numIter,tElapsed,finalResidual] = nmfrule(Data_OFF(:,pixels),3);

trend = (max(max(Li_ON - Li_OFF)))/(max(max((A_ON_NMFGD(:,1) - A_OFF_NMFGD(:,1)))));

% reflectance with NMF-GD
for i = 1 : size(Data_ON,2)       
       Refl_NMFGD(:,i) = (Data_ONc(:,i) - Data_OFFc(:,i)) ./ (trend*(A_ON_NMFGD(:,1) - A_OFF_NMFGD(:,1)));
end
time_NMFGD = toc
% cd([CF0, '\Results']);

% SNMF2: The standard NMF optimized by NNLS active-set algorithm. ==========================================================
addpath([CF0,'\sparse-nmfv1_4'])
cd([CF0,'\sparse-nmfv1_4'])
% ON
tic
[A_ON_NMFNNLS,Yon,numIter,tElapsed,finalResidual] = nmfnnls(Data_ON(:,pixels),3);
%  toc
% OFF
% tic
[A_OFF_NMFNNLS,Yoff,numIter,tElapsed,finalResidual] = nmfnnls(Data_OFF(:,pixels),3);

trend = (max(max(Li_ON - Li_OFF)))/(max(max(A_OFF_NMFNNLS(:,1))));

% Reflectance with NMF-NNLS 
for i = 1 : size(Data_ON,2)       
       Refl_NMFNNLS(:,i) = (Data_ONc(:,i) - Data_OFFc(:,i)) ./ (trend*A_OFF_NMFNNLS(:,1));% - A_OFF_NMFNNLS(:,1)
end
Time_NMFNNLS = toc
%  figure; plot(10000./sigma,Refl_NMFNNLS(:,pixels1))
% Random selection
tic
y_ON = datasample(Data_ON(:,pixels)',1);
y_OFF = datasample(Data_OFF(:,pixels)',1);
for i = 1 : size(Data_ON,2)       
       Refl_Rand(:,i) = (Data_ONc(:,i) - Data_OFFc(:,i)) ./ (y_ON' - y_OFF');
end
time_rand = toc
% cd([CF0, '\Results']);
% showing the infragold spectra       
% figure; hold on,
% plot(10000./sigma,Li_ON,'LineWidth',2, 'color','r'), 
% plot(10000./sigma,Li_OFF,'LineWidth',2, 'color','b'),
% plot(10000./sigma,A_ON_NMFGD(:,1),'LineWidth',2, 'color','g'), 
% plot(10000./sigma, A_OFF_NMFGD(:,1),'LineWidth',2, 'color','k'),
% plot(10000./sigma,A_ON_NMFNNLS(:,1),'LineWidth',2, 'color','m'), 
% plot(10000./sigma,A_OFF_NMFNNLS(:,1),'LineWidth',2, 'color','b'),
% plot(10000./sigma,y_ON,'LineWidth',2, 'color','..r'), 
% plot(10000./sigma,y_OFF,'LineWidth',2, 'color','..b'),
% title('Infragold spectra'), grid on, xlabel(['Wavelength (\mu m)']), ylabel(['Reflectance'])    
% hold off, legend('Mean ON','Mean OFF','ON NMFGD','OFF NMFGD','ON NMFNNLS','OFF NMFNNLS')

figure;
plot(10000./sigma,Li_ON,':',10000./sigma,Li_OFF,':',10000./sigma,A_ON_NMFGD(:,1),...
    10000./sigma, A_OFF_NMFGD(:,1),10000./sigma,A_ON_NMFNNLS(:,1),10000./sigma,A_OFF_NMFNNLS(:,1),...
    10000./sigma,y_ON,'--',10000./sigma,y_OFF,'--','LineWidth',2),%
title('Infragold spectra'), grid on, xlabel(['Wavelength (\mu m)']), ylabel(['Reflectance'])    
legend('Mean ON','Mean OFF','ON NMFGD','OFF NMFGD','ON NMFNNLS','OFF NMFNNLS','ON Rand','OFF Rand')%
cd([CF0, '\Results']);
saveas(gcf,'Infragold spectra','fig')

% figure;
% plot(10000./sigma,Li_ON,':',10000./sigma,Li_OFF,'LineWidth',2),%
% title('Infragold spectra'), grid on, xlabel(['Wavelength (\mu m)']), ylabel(['Reflectance'])    
% legend('Mean ON','Mean OFF','ON NMFGD','OFF NMFGD','ON NMFNNLS','OFF NMFNNLS','ON Rand','OFF Rand')%
% cd([CF0, '\Results']);
% saveas(gcf,'Infragold spectra','fig')

% x = floor(x); y = floor(y);
% Refl_mean = reshape(Reflectance,[SZ(1),SZ(2),size(Reflectance,1)]);
% Refl_NMFGD = reshape(Refl_NMFGD,[SZ(1),SZ(2),size(Reflectance,1)]);
% Refl_NMFNNLS = reshape(Refl_NMFNNLS,[SZ(1),SZ(2),size(Reflectance,1)]);
% Refl_Rand = reshape(Refl_Rand,[SZ(1),SZ(2),size(Reflectance,1)]);

%  Refl_mean1 = reshape(Refl_mean(y,x,:),1,[]);
%  Refl_NMFGD1 = reshape(Refl_NMFGD(y,x,:),1,[]);
%  Refl_NMFNNLS1 = reshape(Refl_NMFNNLS(y,x,:),1,[]);
%  Refl_Rand1 = reshape(Refl_Rand(y,x,:),1,[]);


% ASTER ==========================================================
cd('\\gel.ulaval.ca\Vision\Usagers\bayou2\MATLAB\Col-GEO\ASTER')
reflectance = Reflectance;
ASTER_Biotite = importdata('Biotite.jpl.nicolet.mineral.silicate.phyllosilicate.coarse.ps23a.spectrum.txt');
bandes_IR = find(10000./ASTER_Biotite.data(:,1) > min(sigma) & 10000./ASTER_Biotite.data(:,1) < max(sigma));
% Biotite = resample(ASTER_Biotite,size(reflectance,1),size(bandes_IR,1));
ASTERO = [ASTER_Biotite.data(bandes_IR,1),ASTER_Biotite.data(bandes_IR,2)/100];
Biotite = resample(ASTERO,size(reflectance,1),size(ASTERO,1));

%%%%%
ASTER_Diopside = importdata('Diopside.jhu.nicolet.mineral.silicate.inosilicate.solid.diopsi1.spectrum.txt');
bandes_IR = find(10000./ASTER_Diopside.data(:,1) > min(sigma) & 10000./ASTER_Diopside.data(:,1) < max(sigma));
ASTERO = [ASTER_Diopside.data(bandes_IR,1),ASTER_Diopside.data(bandes_IR,2)/100];
Diopside = resample(ASTERO,size(reflectance,1),size(ASTERO,1));

%%%%%
ASTER_Epidote = importdata('Epidote.jhu.nicolet.mineral.silicate.sorosilicate.solid.epidot1.spectrum.txt');
bandes_IR = find(10000./ASTER_Epidote.data(:,1) > min(sigma) & 10000./ASTER_Epidote.data(:,1) < max(sigma));
ASTERO = [ASTER_Epidote.data(bandes_IR,1),ASTER_Epidote.data(bandes_IR,2)/100];
Epidote = resample(ASTERO,size(reflectance,1),size(ASTERO,1));

%%%%%
ASTER_Goethite = importdata('Goethite.jhu.nicolet.mineral.hydroxide.none.solid.goethi2.spectrum.txt');
bandes_IR = find(10000./ASTER_Goethite.data(:,1) > min(sigma) & 10000./ASTER_Goethite.data(:,1) < max(sigma));
ASTERO = [ASTER_Goethite.data(bandes_IR,1),ASTER_Goethite.data(bandes_IR,2)/100];
Goethite = resample(ASTERO,size(reflectance,1),size(ASTERO,1));

%%%%%
ASTER_Kyanite = importdata('Kyanite.jhu.nicolet.mineral.silicate.phyllosilicate.coarse.kyanit1.spectrum.txt');
bandes_IR = find(10000./ASTER_Goethite.data(:,1) > min(sigma) & 10000./ASTER_Goethite.data(:,1) < max(sigma));
ASTERO = [ASTER_Kyanite.data(bandes_IR,1),ASTER_Kyanite.data(bandes_IR,2)/100];
Kyanite = resample(ASTERO,size(reflectance,1),size(ASTERO,1));

%%%%%
ASTER_Scheelite = importdata('Scheelite.jpl.nicolet.mineral.tungstate.none.coarse.t01a.spectrum.txt');
bandes_IR = find(10000./ASTER_Scheelite.data(:,1) > min(sigma) & 10000./ASTER_Scheelite.data(:,1) < max(sigma));
ASTERO = [ASTER_Scheelite.data(bandes_IR,1),ASTER_Scheelite.data(bandes_IR,2)/100];
Scheelite = resample(ASTERO,size(reflectance,1),size(ASTERO,1));

%%%%%
ASTER_Smithsonite = importdata('Smithsonite.jpl.nicolet.mineral.carbonate.none.coarse.c11a.spectrum.txt');
bandes_IR = find(10000./ASTER_Smithsonite.data(:,1) > min(sigma) & 10000./ASTER_Smithsonite.data(:,1) < max(sigma));
ASTERO = [ASTER_Smithsonite.data(bandes_IR,1),ASTER_Smithsonite.data(bandes_IR,2)/100];
Smithsonite = resample(ASTERO,size(reflectance,1),size(ASTERO,1));

%%%%%
ASTER_Tourmaline = importdata('Tourmaline.jhu.nicolet.mineral.silicate.cyclosilicate.solid.tourma1.spectrum.txt');
bandes_IR = find(10000./ASTER_Tourmaline.data(:,1) > min(sigma) & 10000./ASTER_Tourmaline.data(:,1) < max(sigma));
ASTERO = [ASTER_Tourmaline.data(bandes_IR,1),ASTER_Tourmaline.data(bandes_IR,2)/100];
Tourmaline = resample(ASTERO,size(reflectance,1),size(ASTERO,1));

%%%%%
ASTER_Pyrope = importdata('PYROPE-jhu.nicolet.mineral.silicate.nesosilicate.solid.pyrope1.spectrum.txt');
bandes_IR = find(10000./ASTER_Pyrope.data(:,1) > min(sigma) & 10000./ASTER_Pyrope.data(:,1) < max(sigma));
ASTERO = [ASTER_Pyrope.data(bandes_IR,1),ASTER_Pyrope.data(bandes_IR,2)/100];
Pyrope = resample(ASTERO,size(reflectance,1),size(ASTERO,1));

%%%%%
ASTER_Olivine = importdata('Olivine (Fo92) (Fe+2,Mg)2SiO4 (2) - jhu.nicolet.mineral.silicate.nesosilicate.solid.olivi12.spectrum.txt');
bandes_IR = find(10000./ASTER_Olivine.data(:,1) > min(sigma) & 10000./ASTER_Olivine.data(:,1) < max(sigma));
ASTERO = [ASTER_Olivine.data(bandes_IR,1),ASTER_Olivine.data(bandes_IR,2)/100];
Olivine = resample(ASTERO,size(reflectance,1),size(ASTERO,1));

%%%%%
ASTER_Quartz = importdata('QUARTZ-jhu.nicolet.mineral.silicate.tectosilicate.solid.quartz1.spectrum.txt');
bandes_IR = find(10000./ASTER_Quartz.data(:,1) > min(sigma) & 10000./ASTER_Quartz.data(:,1) < max(sigma));
ASTERO = [ASTER_Quartz.data(bandes_IR,1),ASTER_Quartz.data(bandes_IR,2)/100];
Quartz = resample(ASTERO,size(reflectance,1),size(ASTERO,1));
%%%%%
% % % % Background spectrum selection
% % % title(['Select Background region']);
% % % % tv3 = toc;
% % % BW = roipoly(BY.J); , tic
% % %     [row,col] = find(BW == 1);
% % %     infraGold = [row,col];
% % % addpath('H:\B\Dr-IR-sp\Dr-IR-MATLAB\New Exp. Dec2014 TELOPS\TELOPS')
% % % addpath('H:\B\Dr-IR-sp\Dr-IR-MATLAB\New Exp. Dec2014 TELOPS\TELOPS\Matlab_customer\p_files')
% % %   pixels = getAoiIndices(BY.Header_ON, buildAoi(1, 1, row-1, col-1));
% % % 
% % %     bckgnd = mean(reflectance(:,pixels));
%   bckgnd = resample(double(bckgnd0'), size(bckgnd0,2), size(ASTERO,1));

ASTER = struct('ASTER_Biotite',ASTER_Biotite, 'ASTER_Diopside',ASTER_Diopside ,'ASTER_Epidote',ASTER_Epidote,...
    'ASTER_Goethite',ASTER_Goethite, 'ASTER_Kyanite',ASTER_Kyanite , 'ASTER_Scheelite',ASTER_Scheelite ,...
    'ASTER_Smithsonite',ASTER_Smithsonite , 'ASTER_Tourmaline',ASTER_Tourmaline , 'ASTER_Pyrope',ASTER_Pyrope ,...
    'ASTER_Olivine',ASTER_Olivine , 'ASTER_Quartz',ASTER_Quartz,...
    'Biotite',Biotite , 'Diopside',Diopside, 'Epidote',Epidote , 'Goethite',Goethite , 'Kyanite',Kyanite ,...
    'Scheelite',Scheelite , 'Smithsonite',Smithsonite , 'Tourmaline',Tourmaline , 'Pyrope',Pyrope,...
    'Olivine',Olivine , 'Quartz',Quartz); %, 'bckgnd', bckgnd
clear ASTER_Biotite ASTER_Diopside ASTER_Epidote ASTER_Goethite ASTER_Kyanite ASTER_Scheelite ...
    ASTER_Smithsonite ASTER_Tourmaline ASTER_Pyrope ASTER_Olivine ASTER_Quartz Biotite Diopside...
    Epidote Goethite Kyanite Scheelite Smithsonite Tourmaline Pyrope Olivine Quartz ASTERO bckgnd ...
    BW row col infraGold bckgnd0
% Quantitative calculations ==========================================================
% Reflectance(:,pixels1)
% Refl_NMFGD(:,pixels1)
% Refl_NMFNNLS(:,pixels1)
% Refl_Rand(:,pixels1)

f = {'Reflectance','Refl_NMFGD','Refl_NMFNNLS','Refl_Rand'};
for i = 1 : size(f,2)
    a = eval(['ASTER.',Mineral]);
    b = eval([f{i}]);
    [NCC] = hyperNormXCorr(a(:,2),b(:,round(pixels1)))*100;
    [sam] = (1 - hyperSam(a(:,2),b(:,round(pixels1))))*100;
    disp([f{i},' percentage of NCC:',num2str(NCC), '.....', f{i},' percentage of SAM:',num2str(sam)]);
end
% sgolayfilt(,1,25)
figure;
plot(10000./sigma,sgolayfilt(double(Reflectance(:,round(pixels1))),2,15),':',...
    10000./sigma,sgolayfilt(double(Refl_NMFGD(:,round(pixels1))),2,15),10000./sigma,...
    sgolayfilt(double(Refl_NMFNNLS(:,round(pixels1))),2,15),...
    10000./sigma,sgolayfilt(double(Refl_Rand(:,round(pixels1))),2,15),10000./sigma, a(:,2)+0.1,...
    10000./sigma,sgolayfilt(double(Data_ON(:,round(pixels1))),2,15), 'LineWidth',2),% 
title(['Continuum Removed spectra for ', Mineral]), grid on, xlabel(['Wavelength (\mu m)']), ylabel(['Reflectance'])    
legend('Mean','NMFGD','NMFNNLS','Rand','ASTER','Non-corrected')%
cd([CF0, '\Results']);
% saveas(gcf,['Continuum Removed spectra for ', Mineral,'-',num2str(snr*100)],'fig')




